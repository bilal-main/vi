#pragma once
#include "actions.hpp"
#include "inventory_stats_update.hpp"
#include "map_gen.hpp"
#include "rand.h"
#include "iostream"
#include "fstream"
#include "string"

void main_loop() {
    std::string x=" ";
    while(x!="exit"){
    std::cin>>x;    
    
    player::name_config();

    if(x=="dairy"||x=="d"||x=="D"){
    player::dairy();
    }
    else if (x=="E"||x=="e"||x=="explore"){

    }
    player::explore();
    }
}

