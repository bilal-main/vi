#pragma once
#include <fstream>
#include <iostream>
#include <string>

#include "rand.h"
#include "inventory_stats_update.hpp"

namespace get {
    float lead_count(float &lead_refills) {
        return lead_refills;
    }
};

namespace check {
    void leads_count(float &lead_reffils) {
        system("clear");
        std::cout << "i have: " << lead_refills << " lead reffils" << std::endl;
    }
};

namespace player {

    void name_config() {
        std::ifstream check("player_config.txt");
        bool has_name = false;
        
        if (check.is_open()) {
            if (check.peek() != std::ifstream::traits_type::eof()) {
                std::string existing_name;
                std::getline(check, existing_name);
                if (!existing_name.empty()) {
                    has_name = true;
                }
            }
            check.close();
        }
        
        if (has_name) return;
        
        std::ofstream player_config("player_config.txt");
        std::string playername;
        std::cout << "enter player name: ";
        std::getline(std::cin, playername);
        player_config << playername;
        player_config.close();
    }

    void dairy() {
        if (lead_refills > 0) {
            std::ofstream file("diary.txt", std::ios::app);
            std::string line;
            std::string playername;
            std::ifstream notetext("player_config.txt");
            std::getline(notetext, playername);
            notetext.close();

            std::cout << "Start writing diary (enter 0 to stop):\n";

            while (true) {
                std::cout << playername << ": ";
                std::getline(std::cin, line);
                if (line == "0") break;
                file << line << "\n";
                // ✅ Deduct the cost per line (1 unit per 5 characters)
                lead_refills -= (line.length() / 1220.0);
                check::leads_count(lead_refills);
            }
            file.close();
        }
    }

    void explore() {
        if (Random::OneInFive()) {
            lead_refills += Random::M_To_N(1, 25);
        }
    }
};