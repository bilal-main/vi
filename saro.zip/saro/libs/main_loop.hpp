#include "actions.hpp"
#include "inventory_stats_update.hpp"
#include "map_gen.hpp"
#include "rand.h"
#include "iostream"
#include "fstream"


void main_loop(){
std::ofstream file("test.txt");
file<<"hello"<<123<<0.1;
char x=' ';
while(x!='0'){
std::cout<<"enter: ";std::cin>>x;
file<<x<<std::endl;
}
file.close();

}